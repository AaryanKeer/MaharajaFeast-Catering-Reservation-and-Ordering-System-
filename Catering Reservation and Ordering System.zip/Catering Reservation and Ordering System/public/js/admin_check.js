import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js';
import { getFirestore, doc, getDoc } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js';

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAohJ3qKoPwEj9VBuEqwlITEeIwcOZikAI",
    authDomain: "maharajafeast-9fc24.firebaseapp.com",
    projectId: "maharajafeast-9fc24",
    storageBucket: "maharajafeast-9fc24.appspot.com",
    messagingSenderId: "185226724240",
    appId: "1:185226724240:web:5ca8cca6f7765c96492915",
    measurementId: "G-JPTR23RKTD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Debugging: Check if user is an admin
async function checkIfAdmin(uid) {
    console.log(`Checking admin status for user UID: ${uid}`);  // Debug: Log the UID being checked
    try {
        const adminRef = doc(db, 'admins', uid);
        const adminDoc = await getDoc(adminRef);

        if (adminDoc.exists()) {
            console.log('Admin document found:', adminDoc.data());  // Debug: Log the document data if it exists
            return true; // User is an admin
        } else {
            console.log('No admin document found for this user.');  // Debug: Log if no document is found
            return false; // User is not an admin
        }
    } catch (error) {
        console.error('Error checking admin status:', error);  // Debug: Log any errors encountered
        return false;
    }
}

// Verify admin access and redirect if necessary
export function verifyAdminAccess() {
    onAuthStateChanged(auth, async (user) => {
        if (user) {
            const isAdmin = await checkIfAdmin(user.uid);
            console.log('Is Admin:', isAdmin);  // Debug: Log if the user is an admin or not

            if (!isAdmin) {
                // Redirect to user home page if not an admin
                window.location.href = 'user_home.html';
            }
        } else {
            // Redirect to index page if not signed in
            window.location.href = 'index.html';
        }
    });
}

// Call verifyAdminAccess function in each admin page
verifyAdminAccess();
