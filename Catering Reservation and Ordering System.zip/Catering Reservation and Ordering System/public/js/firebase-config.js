// Import Firebase services
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyAohJ3qKoPwEj9VBuEqwlITEeIwcOZikAI",
    authDomain: "maharajafeast-9fc24.firebaseapp.com",
    projectId: "maharajafeast-9fc24",
    storageBucket: "maharajafeast-9fc24.appspot.com",
    messagingSenderId: "185226724240",
    appId: "1:185226724240:web:5ca8cca6f7765c96492915",
    measurementId: "G-JPTR23RKTD"
  };

// Initialize Firebase app only if it hasn't been initialized
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);
const analytics = getAnalytics(app);

export { auth, db };
