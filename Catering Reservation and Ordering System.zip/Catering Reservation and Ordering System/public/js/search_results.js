import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";
import { getFirestore, collection, query, where, getDocs, doc, getDoc, addDoc } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAohJ3qKoPwEj9VBuEqwlITEeIwcOZikAI",
    authDomain: "maharajafeast-9fc24.firebaseapp.com",
    projectId: "maharajafeast-9fc24",
    storageBucket: "maharajafeast-9fc24.appspot.com",
    messagingSenderId: "185226724240",
    appId: "1:185226724240:web:5ca8cca6f7765c96492915",
    measurementId: "G-JPTR23RKTD"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener('DOMContentLoaded', () => {
    const searchParams = new URLSearchParams(window.location.search);
    const city = searchParams.get('city');
    const category = searchParams.get('category');
    const searchResultsElement = document.getElementById('search-results');

    if (!city || !category) {
        searchResultsElement.textContent = 'No city or category selected.';
        return;
    }

    // Ensure the user is authenticated before proceeding
    onAuthStateChanged(auth, (user) => {
        if (user) {
            fetchCateringServices(city, category, user.uid);
        } else {
            searchResultsElement.textContent = 'You need to be logged in to view services.';
        }
    });
});

async function fetchCateringServices(city, category, userId) {
    const searchResultsElement = document.getElementById('search-results');

    try {
        // Query admins based on the city
        const adminsRef = collection(db, 'admins');
        const adminQuery = query(adminsRef, where('city', '==', city));
        const adminSnapshot = await getDocs(adminQuery);

        if (adminSnapshot.empty) {
            searchResultsElement.textContent = 'No services found for the selected criteria.';
        } else {
            const resultsHtml = await Promise.all(adminSnapshot.docs.map(async (adminDoc) => {
                const adminData = adminDoc.data();
                const productsRef = collection(db, 'products');

                // Query products based on the admin ID and category
                const productsQuery = query(productsRef, where('adminId', '==', adminDoc.id), where('category', '==', category));
                const productsSnapshot = await getDocs(productsQuery);

                if (productsSnapshot.empty) {
                    return ''; // No products for this admin in the given category
                }

                return productsSnapshot.docs.map(productDoc => {
                    const productData = productDoc.data();
                    return `
                        <div class="service-item">
                            <h3>${adminData.cateringName}</h3>
                            <p>Product: ${productData.name}</p>
                            <p>Description: ${productData.description}</p>
                            <p>Price: ₹${productData.price}</p>
                            <button class="buy-btn" data-product-id="${productDoc.id}" data-admin-id="${adminDoc.id}">Buy</button>
                        </div>
                    `;
                }).join('');
            }));

            searchResultsElement.innerHTML = resultsHtml.filter(html => html !== '').join('');
        }
    } catch (error) {
        console.error('Error fetching search results:', error.message);
        searchResultsElement.textContent = 'An error occurred while fetching search results.';
    }
}

// Event listener for buy buttons
document.addEventListener('click', async (event) => {
    if (event.target.classList.contains('buy-btn')) {
        const productId = event.target.getAttribute('data-product-id');
        const adminId = event.target.getAttribute('data-admin-id');
        const userId = auth.currentUser ? auth.currentUser.uid : null;

        if (!userId) {
            alert('You need to be logged in to place an order.');
            return;
        }

        try {
            // Add order to Firestore
            await addDoc(collection(db, 'orders'), {
                userId,
                adminId,
                productId,
                status: 'Pending',
                orderDate: new Date(),
            });

            alert('Order placed successfully!');
        } catch (error) {
            console.error('Error placing order:', error);
            alert('An error occurred while placing the order.');
        }
    }
});
