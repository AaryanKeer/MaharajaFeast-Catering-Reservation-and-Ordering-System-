import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, where } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAohJ3qKoPwEj9VBuEqwlITEeIwcOZikAI",
    authDomain: "maharajafeast-9fc24.firebaseapp.com",
    projectId: "maharajafeast-9fc24",
    storageBucket: "maharajafeast-9fc24.appspot.com",
    messagingSenderId: "185226724240",
    appId: "1:185226724240:web:5ca8cca6f7765c96492915",
    measurementId: "G-JPTR23RKTD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", () => {
    const addProductForm = document.getElementById("add-product-form");
    const productList = document.getElementById("product-list");

    onAuthStateChanged(auth, async (user) => {
        if (user) {
            user.getIdTokenResult().then((idTokenResult) => {
                console.log("Token claims:", idTokenResult.claims);
            });


            // Listen for form submission
            addProductForm.addEventListener("submit", async (event) => {
                event.preventDefault();

                // Get form values
                const productName = document.getElementById("product-name").value;
                const productCategory = document.getElementById("product-category").value;
                const productDescription = document.getElementById("product-description").value;
                const productPrice = parseFloat(document.getElementById("product-price").value);
                const productCity = document.getElementById("product-city").value;

                try {
                    // Add product to Firestore
                    await addDoc(collection(db, "products"), {
                        name: productName,
                        category: productCategory,
                        description: productDescription,
                        price: productPrice,
                        city: productCity,
                        adminId: user.uid // Associate the product with the admin
                    });

                    // Clear form after successful submission
                    addProductForm.reset();
                    alert("Product added successfully!");

                    // Refresh product list
                    displayProducts(user.uid);
                } catch (error) {
                    console.error("Error adding product: ", error);
                    alert("Failed to add product.");
                }
            });
        } else {
            // Redirect to login page if not authenticated
            window.location.href = "admin_login.html";
        }
    });

    async function displayProducts(adminId) {
        try {
            // Clear current product list
            productList.innerHTML = "";

            // Fetch products from Firestore for the logged-in admin
            const productsQuery = query(collection(db, "products"), where("adminId", "==", adminId));
            const querySnapshot = await getDocs(productsQuery);
            querySnapshot.forEach((doc) => {
                const product = doc.data();

                // Create a div to display the product
                const productDiv = document.createElement("div");
                productDiv.classList.add("product-item");
                productDiv.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>Category: ${product.category}</p>
                    <p>Description: ${product.description}</p>
                    <p>Price: ₹${product.price.toFixed(2)}</p>
                    <p>City: ${product.city}</p>
                `;
                productList.appendChild(productDiv);
            });
        } catch (error) {
            console.error("Error fetching products: ", error);
            alert("Failed to load products.");
        }
    }
});
