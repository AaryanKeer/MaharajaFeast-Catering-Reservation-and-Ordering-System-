// Import the functions you need from the Firebase SDK
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js';
import { getFirestore, collection, query, where, getDocs, doc, getDoc, updateDoc } from 'https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js';

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAohJ3qKoPwEj9VBuEqwlITEeIwcOZikAI",
    authDomain: "maharajafeast-9fc24.firebaseapp.com",
    projectId: "maharajafeast-9fc24",
    storageBucket: "maharajafeast-9fc24.appspot.com",
    messagingSenderId: "185226724240",
    appId: "1:185226724240:web:5ca8cca6f7765c96492915",
    measurementId: "G-JPTR23RKTD"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener('DOMContentLoaded', function () {
    const ordersTbody = document.getElementById('orders-tbody');
    const userName = document.getElementById('user-name');
    const userEmail = document.getElementById('user-email');
    const userAddress = document.getElementById('user-address');

    onAuthStateChanged(auth, async (user) => {
        if (user) {
            const userId = user.uid;
            console.log('Current user UID:', userId); // Log the user ID

            try {
                // Fetch orders for the logged-in user
                const ordersQuery = query(collection(db, 'orders'));
                const querySnapshot = await getDocs(ordersQuery);

                for (const docSnap of querySnapshot.docs) {
                    const order = docSnap.data();
                    const row = document.createElement('tr');

                    const orderIdCell = document.createElement('td');
                    orderIdCell.textContent = docSnap.id; // Use document ID as Order ID
                    row.appendChild(orderIdCell);

                    const orderDateCell = document.createElement('td');
                    orderDateCell.textContent = order.orderDate.toDate().toLocaleDateString(); // Format date as needed
                    row.appendChild(orderDateCell);

                    const orderDetailsCell = document.createElement('td');
                    const productRef = doc(db, 'products', order.productId);
                    const productDoc = await getDoc(productRef);
                    if (productDoc.exists()) {
                        const productData = productDoc.data();
                        orderDetailsCell.textContent = `Product: ${productData.name}, Price: ₹${productData.price}`;
                    } else {
                        orderDetailsCell.textContent = 'Product details not found';
                    }
                    row.appendChild(orderDetailsCell);

                    const statusCell = document.createElement('td');
                    statusCell.textContent = order.status;
                    row.appendChild(statusCell);

                    const actionsCell = document.createElement('td');

                    // Request Modification button
                    const requestModificationButton = document.createElement('button');
                    requestModificationButton.className = 'action-btn';
                    requestModificationButton.textContent = 'Request Modification';
                    requestModificationButton.onclick = () => requestModification(docSnap.id);
                    actionsCell.appendChild(requestModificationButton);

                    // Request Cancellation button
                    const requestCancellationButton = document.createElement('button');
                    requestCancellationButton.className = 'action-btn';
                    requestCancellationButton.textContent = 'Cancel Order';
                    requestCancellationButton.onclick = () => cancelOrder(docSnap.id);
                    actionsCell.appendChild(requestCancellationButton);

                    row.appendChild(actionsCell);
                    ordersTbody.appendChild(row);
                }

                // Fetch user details and populate them
                const userDoc = await getDoc(doc(db, 'users', userId));
                if (userDoc.exists()) {
                    const userData = userDoc.data();
                    userName.textContent = userData.name || "Name not provided";
                    userEmail.textContent = userData.email || "Email not provided";
                    userAddress.textContent = userData.address || "Address not provided";
                } else {
                    console.log("No such user!");
                }
            } catch (error) {
                console.error('Error fetching orders:', error);
            }
        } else {
            // Redirect to login page if user is not authenticated
            window.location.href = 'index.html';
        }
    });

    async function requestModification(orderId) {
        console.log('Requesting modification for order:', orderId);

        const orderRef = doc(db, 'orders', orderId);
        try {
            await updateDoc(orderRef, {
                status: 'Modification Requested'
            });
            alert('Modification request submitted.');
        } catch (error) {
            console.error('Error requesting modification:', error);
        }
    }

    async function cancelOrder(orderId) {
        console.log('Cancelling order:', orderId);

        const orderRef = doc(db, 'orders', orderId);
        try {
            await updateDoc(orderRef, {
                status: 'Cancelled'
            });
            alert('Order has been cancelled.');
        } catch (error) {
            console.error('Error cancelling order:', error);
        }
    }
});
