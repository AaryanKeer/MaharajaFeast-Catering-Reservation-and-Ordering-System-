document.addEventListener('DOMContentLoaded', (event) => {
    // Toggle dropdown menu on smaller screens
    const dropdowns = document.querySelectorAll('.dropbtn');
    dropdowns.forEach(dropbtn => {
        dropbtn.addEventListener('click', (event) => {
            const dropdownContent = event.target.nextElementSibling;
            dropdownContent.classList.toggle('show');
        });
    });

    // Close the dropdown menu if the user clicks outside of it
    window.onclick = function(event) {
        if (!event.target.matches('.dropbtn')) {
            const dropdownContents = document.querySelectorAll(".dropdown-content");
            dropdownContents.forEach(dropdownContent => {
                if (dropdownContent.classList.contains('show')) {
                    dropdownContent.classList.remove('show');
                }
            });
        }
    }

    // Handle search button click
    const searchButton = document.getElementById('search-button');
    searchButton.addEventListener('click', () => {
        const city = document.getElementById('city-select').value;
        const category = document.getElementById('category-select').value;

        if (city && category) {
            alert(`Searching for ${category} catering services in ${city}`);
            // Add logic to search and display results (Firebase integration)
        } else {
            alert('Please select both a city and a catering service category.');
        }
    });

    // Handle "Buy" button click
    const buyButtons = document.querySelectorAll('.buy-button');
    buyButtons.forEach(button => {
        button.addEventListener('click', () => {
            const isLoggedIn = false; // Replace with actual logic to check if user is logged in
            if (!isLoggedIn) {
                const loginMessage = button.nextElementSibling;
                loginMessage.style.display = 'inline-block';
            } else {
                // Add logic to handle purchase flow or redirect to login page
                alert('Please login before purchasing.');
            }
        });
    });

});
