// Listen for form submission
document.getElementById('adminSignupForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting normally

    const email = document.getElementById('admin-email').value;
    const password = document.getElementById('admin-password').value;
    const cateringName = document.getElementById('catering-name').value;
    const city = document.getElementById('city').value;
    const mobile = document.getElementById('mobile').value;
    const ownerName = document.getElementById('owner-name').value;

    // Call your Cloud Function endpoint
    fetch('<CLOUD_FUNCTION_ENDPOINT>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            email: email,
            password: password,
            cateringName: cateringName,
            city: city,
            mobile: mobile,
            ownerName: ownerName
        })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Admin signup response:', data);
        // Handle success, e.g., redirect to admin home page
        window.location.href = 'admin_home.html';
    })
    .catch(error => {
        console.error('Error signing up admin:', error);
        // Handle errors, e.g., show error message to user
        alert('Failed to signup admin. Please try again.');
    });
});
